module.exports.creds = {
    consumer_key:         'tqqbV6HjKxBGLz5PMnKARj4nH',
    consumer_secret:      'XGorIIGMO9s9NnyBdbjbsHjC2JUoh8UJn7nUtx9IzT0JBN32HY',
    access_token:         '929364133845393409-86mQG9LwIfI6VZOUsaaozPPTWnbz6k3',
    access_token_secret:  'w0uPbhLyHqU2baQ9wko9zizQGtVZnnhdv1iIYuZqFAteF',
};

module.exports.hastags = "#clojurescript";