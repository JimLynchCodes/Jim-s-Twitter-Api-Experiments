const t = require('./fav-bot');

function doTwitterCall() {

    t();

}

doTwitterCall();