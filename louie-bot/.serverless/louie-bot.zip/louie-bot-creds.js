module.exports.creds = {
    consumer_key:         'a6wbwyHArJRZebH4e3y0r796V',
    consumer_secret:      '247w115Gn5gvGtuvOXRmKwfGuwrXuBxtbdcPJGk4b06y6B7uLf',
    access_token:         '944218042254413826-aP3gqFrdRfrgAxdp9rXm2SiiZAKWa1T',
    access_token_secret:  'C9ShDtfdEsE6qd6rjucBnKcAuK4fTl4btqEPmEcxFdBmF',
};

module.exports.hastags = [ "puppy", "puppies", "frenchbulldog" ];
